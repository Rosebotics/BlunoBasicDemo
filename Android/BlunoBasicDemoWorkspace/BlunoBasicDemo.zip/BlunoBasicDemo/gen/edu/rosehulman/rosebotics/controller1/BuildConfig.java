/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.rosebotics.controller1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}